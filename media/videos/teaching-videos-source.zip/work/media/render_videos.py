"""Deterministic Pillow teaching animation + real narration -> H.264/AAC MP4.

Every frame is a pure function of its measured audio timeline and timestamp.
No GUI, external requests, random values, wall-clock animation, or scientific
measurement synthesis is used. Canvas labels are English; captions follow voice.
"""
from pathlib import Path
import argparse, functools, hashlib, json, math, os, re, subprocess, time
from PIL import Image, ImageDraw, ImageFont

ROOT=Path(__file__).resolve().parent
OUT=ROOT.parents[1]/'dist/media/videos'
FFMPEG=os.environ.get('FFMPEG_BIN','/Users/macbook/Documents/Codex/tools/teaching-video/.venv/lib/python3.12/site-packages/imageio_ffmpeg/binaries/ffmpeg-macos-aarch64-v7.1')
W,H,FPS=1920,1080,24
BG='#0c171d'; PANEL='#14262e'; RAISED='#1b303a'; LINE='#30454e'; TEXT='#edf4f0'; MUTED='#a2b6bd'; DIM='#6a848e'; MINT='#b6f4cf'; BLUE='#a8d5f4'; GOLD='#f0cc85'; RED='#f09e9b'
REG='/System/Library/Fonts/Avenir Next.ttc'
MONO='/System/Library/Fonts/Menlo.ttc'
CJK='/System/Library/Fonts/Hiragino Sans GB.ttc'

@functools.lru_cache(None)
def font(size,kind='regular'):
    return ImageFont.truetype(CJK if kind=='zh' else MONO if kind=='mono' else REG,size,index=0 if kind in ('bold','zh','mono') else 7)

def text(d,xy,s,size=32,fill=TEXT,kind='regular',anchor=None):
    d.text(xy,s,font=font(size,kind),fill=fill,anchor=anchor)

def rr(d,box,fill=PANEL,outline=LINE,width=2,r=23):
    d.rounded_rectangle(box,radius=r,fill=fill,outline=outline,width=width)

def fit_lines(d,s,size,width,kind='regular'):
    words=list(s) if kind=='zh' else s.split(' ')
    sep='' if kind=='zh' else ' '
    lines=[];line=''
    for word in words:
        nxt=line+sep+word if line else word
        if d.textlength(nxt,font=font(size,kind))>width and line:
            lines.append(line);line=word
        else:line=nxt
    if line:lines.append(line)
    return lines

def wrapped(d,xy,s,size=32,fill=TEXT,width=450,kind='regular',gap=10):
    for i,line in enumerate(fit_lines(d,s,size,width,kind)):
        text(d,(xy[0],xy[1]+i*(size+gap)),line,size,fill,kind)

def ease(x):
    x=max(0,min(1,x));return x*x*(3-2*x)

def path(d,points,color=LINE,width=5,head=True):
    d.line(points,fill=color,width=width,joint='curve')
    if head:
        a,b=points[-2:];angle=math.atan2(b[1]-a[1],b[0]-a[0]);z=17
        d.polygon([b,(b[0]-z*math.cos(angle-.45),b[1]-z*math.sin(angle-.45)),(b[0]-z*math.cos(angle+.45),b[1]-z*math.sin(angle+.45))],fill=color)

def traveling(d,points,p,color=MINT):
    lengths=[math.dist(a,b) for a,b in zip(points,points[1:])];total=sum(lengths);r=max(0,min(1,p))*total
    for i,length in enumerate(lengths):
        if r<=length:
            a,b=points[i:i+2];f=r/length if length else 0;x=a[0]+(b[0]-a[0])*f;y=a[1]+(b[1]-a[1])*f
            d.ellipse((x-11,y-11,x+11,y+11),fill=color,outline=BG,width=3);return
        r-=length

def pill(d,box,label,color=MINT,size=25):
    rr(d,box,PANEL,color,2,17);text(d,((box[0]+box[2])/2,(box[1]+box[3])/2),label,size,color,anchor='mm')

def phase(t,timeline):
    cues=timeline['cues'];i=0
    for j,c in enumerate(cues):
        if t>=c['start']:i=j
    c=cues[i];end=cues[i+1]['start'] if i+1<len(cues) else timeline['duration']
    return i,max(0,min(1,(t-c['start'])/(end-c['start']))),c

def heading(d,t,timeline,chapter,title,subtitle):
    text(d,(80,45),f'RSI-ANYTHING    /    {chapter}',25,MINT,'bold')
    text(d,(80,99),title,58,TEXT,'bold')
    text(d,(82,178),subtitle,28,MUTED)
    text(d,(1840,62),f'{t:04.1f} / {timeline["duration"]:04.1f}s',25,MUTED,'mono',anchor='rm')
    d.line((80,227,1840,227),fill=LINE,width=2)

def captions(d,t,timeline):
    rr(d,(68,902,1852,1030),'#101f26',LINE,1,20)
    current=next((c for c in timeline['cues'] if c['start']<=t<c['end']),None)
    if current:
        kind='zh' if timeline['lang']=='zh' else 'regular'
        lines=fit_lines(d,current['subtitle'],38,1660,kind)
        y=966-(len(lines)*(48)-10)/2
        for i,line in enumerate(lines):text(d,(960,y+i*48),line,38,TEXT,kind,anchor='mt')
    text(d,(80,1052),'SOURCE  arXiv:2610.13912v1   |   Original teaching animation; illustrative states, no invented measurements.',21,DIM)
    d.rounded_rectangle((80,877,1840,884),radius=4,fill=LINE)
    if t>0:d.rounded_rectangle((80,877,80+1760*min(1,t/timeline['duration']),884),radius=4,fill=MINT)

def card(d,x,y,num,title,body,active=False,done=False,width=510,height=165):
    color=MINT if active else LINE
    rr(d,(x,y,x+width,y+height),RAISED if active else PANEL,color,3 if active else 2)
    text(d,(x+27,y+19),num,24,MINT if active or done else DIM,'mono')
    text(d,(x+27,y+54),title,34,TEXT if active or done else MUTED,'bold')
    wrapped(d,(x+27,y+106),body,24,MUTED,width-52,gap=4)

def draw_loop(d,t,timeline):
    i,p,c=phase(t,timeline)
    heading(d,t,timeline,'01  THE LOOP','What survives to the next round?','Prediction guides a decision. Observed feedback may justify a persistent, checked update.')
    positions=[(90,280),(705,280),(1320,280),(1320,585),(705,585),(90,585)]
    nodes=[('01','Proposed actions','Policy k proposes candidates'),('02','Predicted outcomes','Model k forecasts consequences'),('03','External selection','Feasibility + feedback budget'),('04','Observed feedback','Keep forecasts and observations apart'),('05','Proposed updates','Policy / model: separate update routes'),('06','Acceptance checks','Component checks, then pair check')]
    act=[set(),{0,1},{2,3},{4},{5},set()][i]
    reached=[set(),set(),{0,1},{0,1,2,3},{0,1,2,3,4},set(range(6))][i]
    for j,((x,y),node) in enumerate(zip(positions,nodes)):
        card(d,x,y,*node,active=j in act,done=j in reached)
    connections=[[(600,362),(705,362)],[(1215,362),(1320,362)],[(1575,445),(1575,585)],[(1320,667),(1215,667)],[(705,667),(600,667)]]
    for j,pts in enumerate(connections):
        threshold=[1,2,2,3,4][j];col=MINT if i>=threshold else LINE
        path(d,pts,col,5)
        if i==threshold:traveling(d,pts,(p+.19*j)%1)
    text(d,(1610,496),'external',24,MUTED)
    text(d,(1610,525),'evidence',24,MUTED)
    # Model adaptation is conditional; an update attempt is not retention.
    if i==3:
        pill(d,(695,470,1327,535),'Adapt model only if: unreliable + data + budget',GOLD,22)
    elif i==4:
        pill(d,(528,475,1360,535),'Assess components AND the assembled decision system',GOLD,24)
    elif i!=0:
        text(d,(955,510),'Predict  /  act  /  observe  /  revise  /  check',29,DIM,anchor='mm')
    rr(d,(90,791,1830,851),RAISED,MINT if i in (0,5) else LINE,3 if i in (0,5) else 2,19)
    label='CURRENT RETAINED PAIR  ·  Policy k + Model k' if i<5 else 'NEXT ROUND  ·  Accepted pair + accumulated feedback history'
    text(d,(960,821),label,30,MINT if i in (0,5) else MUTED,'bold',anchor='mm')
    if i==5:
        pts=[(345,750),(345,770),(58,770),(58,250),(345,250),(345,280)]
        path(d,pts,MINT,5);traveling(d,pts,p)
    if i==0:
        text(d,(963,509),'Start with versions that were actually retained.',31,MINT,anchor='mm')

def draw_repair(d,t,timeline):
    i,p,c=phase(t,timeline)
    heading(d,t,timeline,'02  CODE REPAIR','Four forecasts. One observed result.','Fixed coder; illustrative candidate sketches. This is a teaching example, not a benchmark run.')
    pill(d,(90,253,574,310),'CODER  ·  same fixed parameters',BLUE,26)
    candidates=[('A','left = mid'),('B','left = mid + 1'),('C','right = mid'),('D','return -1')]
    for j,(letter,code) in enumerate(candidates):
        y=337+j*115;selected=j==1 and i>=2
        rr(d,(90,y,574,y+93),RAISED if selected else PANEL,MINT if selected else LINE,3 if selected else 2,17)
        text(d,(115,y+23),letter,35,MINT if selected else MUTED,'bold')
        text(d,(178,y+17),code,29,TEXT if i>=1 else DIM,'mono')
        if i>=3:text(d,(178,y+56),'SELECTED' if selected else 'not observed',22,MINT if selected else DIM)
        pts=[(574,y+46),(624,y+46),(624,465),(690,465)]
        path(d,pts,MINT if i==2 else LINE,3,False)
        if i==2:traveling(d,pts,(p+j*.2)%1,MINT)
    rr(d,(690,337,1178,655),RAISED if i in (2,5) else PANEL,MINT if i in (2,5) else LINE,3,23)
    text(d,(721,366),'WORLD MODEL',25,MINT,'bold')
    text(d,(721,417),'Predict outcomes',33,TEXT,'bold')
    text(d,(721,472),'Rank before testing',29,MUTED)
    pill(d,(720,533,1148,590),'B preferred in this illustration',MINT if i>=2 else LINE,25)
    text(d,(721,609),'No numeric probabilities invented',21,DIM)
    pts=[(1178,458),(1290,458)]
    path(d,pts,MINT if i>=3 else LINE,5)
    if i==3:traveling(d,pts,p)
    rr(d,(1290,337,1830,557),RAISED if i==3 else PANEL,MINT if i>=3 else LINE,3,23)
    text(d,(1320,367),'EXTERNAL EXECUTION',25,MINT if i>=3 else DIM,'bold')
    text(d,(1320,421),'Test selected patch B',36,TEXT if i>=3 else MUTED,'bold')
    text(d,(1320,485),'ONE selected candidate',29,MINT if i>=3 else DIM)
    pts=[(1560,557),(1560,619)]
    path(d,pts,MINT if i>=4 else LINE,4)
    rr(d,(1290,620,1830,736),PANEL,MINT if i>=4 else LINE,3,19)
    text(d,(1320,642),'OBSERVED FEEDBACK  ·  B only',28,MINT if i>=4 else DIM,'bold')
    text(d,(1320,689),'Stored separately from its forecast',24,MUTED)
    pts=[(1290,680),(1232,680),(1232,772),(1178,772)]
    path(d,pts,GOLD if i>=4 else LINE,4)
    if i==4:traveling(d,pts,p,GOLD)
    rr(d,(690,714,1178,830),PANEL,GOLD if i>=4 else LINE,3,19)
    text(d,(721,733),'CONDITIONAL ADAPTATION',26,GOLD if i>=4 else DIM,'bold')
    text(d,(721,781),'Eligible feedback can revise predictor',25,MUTED)
    if i==5:
        pts=[(690,772),(651,772),(651,308),(933,308),(933,337)]
        path(d,pts,MINT,4);traveling(d,pts,p)
        pill(d,(1280,780,1830,835),'Later rankings may change if retained',MINT,25)
    elif i==0:
        text(d,(1292,796),'Prediction is not an observation.',30,MUTED)
    text(d,(90,822),'Toy patch snippets, not complete programs.',23,DIM)

def pair_card(d,x,y,w,title,version,active=False,color=MINT,checked=False):
    rr(d,(x,y,x+w,y+322),RAISED if active else PANEL,color if active else LINE,3,23)
    text(d,(x+28,y+25),title,25,color if active else MUTED,'bold')
    for j,component in enumerate(['Policy','World model']):
        yy=y+88+j*102
        rr(d,(x+26,yy,x+w-26,yy+78),BG,MINT if checked else LINE,2,16)
        text(d,(x+48,yy+22),f'{component} {version}',29,TEXT,'bold')
        if checked:text(d,(x+w-45,yy+39),'PASS',24,MINT,'bold',anchor='rm')

def draw_retention(d,t,timeline):
    i,p,c=phase(t,timeline)
    heading(d,t,timeline,'03  RETENTION','Passing pieces can still fail as a pair.','Illustrative gate outcome. Acceptance criteria are declared before the comparison.')
    pair_card(d,90,285,475,'CURRENT SYSTEM','k',active=i in (0,3,4,5),color=MINT)
    pair_card(d,675,285,510,'CANDIDATE SYSTEM','new',active=i in (0,1,2),checked=i>=1)
    pts=[(565,446),(675,446)]
    path(d,pts,GOLD if i==0 else LINE,4)
    if i==0:traveling(d,pts,p,GOLD)
    text(d,(620,380),'update',24,GOLD if i==0 else DIM,anchor='mm')
    pts=[(1185,446),(1290,446)]
    path(d,pts,GOLD if i>=2 else LINE,4)
    if i==2:traveling(d,pts,p,GOLD)
    gatecolor=RED if i>=3 else GOLD if i==2 else LINE
    rr(d,(1290,332,1830,560),RAISED,gatecolor,3,23)
    text(d,(1323,361),'PAIR CHECK',28,gatecolor if i>=2 else MUTED,'bold')
    wrapped(d,(1323,411),'Matched evaluation conditions',31,TEXT,450,gap=5)
    if i>=3:pill(d,(1320,498,1798,546),'FAIL  ·  keep the full previous pair',RED,24)
    else:text(d,(1323,511),'Combined decision behavior',25,MUTED)
    if i>=3:
        pts=[(1560,560),(1560,663),(328,663),(328,607)]
        path(d,pts,MINT,5)
        if i==3:traveling(d,pts,p)
        pill(d,(606,631,1219,693),'NEXT CYCLE  ·  Policy k + World model k',MINT,27)
    elif i==2:
        text(d,(93,654),'Individual quality does not establish compatible decision behavior.',31,GOLD)
    elif i==1:
        text(d,(93,654),'Two component passes do not automatically accept the assembled system.',30,MINT)
    else:
        text(d,(93,654),'A proposed update is still a candidate.',32,GOLD)
    if i==4:
        rr(d,(90,747,1830,842),PANEL,GOLD,2,20)
        text(d,(123,766),'RELIABILITY: insufficient coverage',30,GOLD,'bold')
        text(d,(123,807),'Insufficient evidence ≠ reliable; it does not activate the unreliability adaptation trigger.',25,MUTED)
    elif i==5:
        for x,label,col in [(90,'1  SELECT AN ACTION',BLUE),(680,'2  ATTEMPT AN UPDATE',GOLD),(1270,'3  ACCEPT A SYSTEM',MINT)]:
            pill(d,(x,760,x+560,833),label,col,27)
    else:
        text(d,(93,784),'Update data build candidates. Gate data decide retention.',30,MUTED)
        text(d,(93,827),'A designated audit set is reserved for final reporting.',24,DIM)

def render_frame(t,timeline):
    im=Image.new('RGB',(W,H),BG);d=ImageDraw.Draw(im)
    {'loop':draw_loop,'repair':draw_repair,'retention':draw_retention}[timeline['clip']](d,t,timeline)
    captions(d,t,timeline)
    return im

def run(args,**kwargs):
    return subprocess.run(args,capture_output=True,text=True,check=True,**kwargs)

def encode(timeline,preview=False):
    key=timeline['key'];duration=min(4,timeline['duration']) if preview else timeline['duration']
    output=(ROOT/'qa'/f'{key}-preview.mp4') if preview else OUT/f'{key}.mp4'
    output.parent.mkdir(parents=True,exist_ok=True)
    audio=ROOT/timeline['narrationFile']
    log=ROOT/'qa'/f'{key}-encode.log'
    args=[FFMPEG,'-y','-hide_banner','-loglevel','warning','-f','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r',str(FPS),'-i','pipe:0','-i',str(audio),'-map','0:v:0','-map','1:a:0','-t',str(duration),'-c:v','libx264','-preset','veryfast','-crf','20','-pix_fmt','yuv420p','-r',str(FPS),'-c:a','aac','-b:a','160k','-ar','48000','-movflags','+faststart',str(output)]
    started=time.monotonic()
    with log.open('wb') as err:
        process=subprocess.Popen(args,stdin=subprocess.PIPE,stdout=subprocess.DEVNULL,stderr=err)
        try:
            for f in range(round(duration*FPS)):
                process.stdin.write(render_frame(f/FPS,timeline).tobytes())
            process.stdin.close()
            assert process.wait()==0,log.read_text()
        except:
            process.kill();raise
    return {'key':key,'seconds':duration,'frameCount':round(duration*FPS),'renderWallSeconds':round(time.monotonic()-started,2),'bytes':output.stat().st_size,'sha256':hashlib.sha256(output.read_bytes()).hexdigest()}

def verify(timeline):
    key=timeline['key'];video=OUT/f'{key}.mp4';qa=ROOT/'qa'
    # FFmpeg probes streams and completely decodes both audio and video.
    decoded=run([FFMPEG,'-hide_banner','-v','error','-i',str(video),'-map','0:v:0','-map','0:a:0','-f','null','-'])
    probe=subprocess.run([FFMPEG,'-hide_banner','-i',str(video)],capture_output=True,text=True)
    (qa/f'{key}-streams.txt').write_text(probe.stderr)
    assert '1920x1080' in probe.stderr and '24 fps' in probe.stderr and 'Audio: aac' in probe.stderr
    volume=run([FFMPEG,'-hide_banner','-i',str(video),'-vn','-af','volumedetect','-f','null','-']).stderr
    (qa/f'{key}-volume.txt').write_text(volume)
    mean=float(re.search(r'mean_volume: ([-\d.]+) dB',volume)[1]);peak=float(re.search(r'max_volume: ([-\d.]+) dB',volume)[1])
    assert -36<mean<-5,(key,mean)
    assert -1>peak or peak<=-.1,(key,peak)
    times=sorted(set([0,round(timeline['duration']-.125,3)]+[round(c['start']+min(1.0,c['audioDuration']/2),3) for c in timeline['cues']]+[round(c['start']-.04,3) for c in timeline['cues'][1:]]))
    for j,t in enumerate(times):
        run([FFMPEG,'-y','-loglevel','error','-ss',str(t),'-i',str(video),'-frames:v','1','-q:v','2',str(qa/f'{key}-decoded-{j:02d}.jpg')])
    # Use a representative process frame rather than an opening title as poster.
    poster_time=timeline['cues'][3]['start']+.6
    run([FFMPEG,'-y','-loglevel','error','-ss',str(poster_time),'-i',str(video),'-frames:v','1','-q:v','2',str(OUT/f'{key}.jpg')])
    # Independent arbitrary-order calls are identical by construction and hash.
    seek_t=timeline['cues'][3]['start']+.4
    before=hashlib.sha256(render_frame(seek_t,timeline).tobytes()).hexdigest()
    render_frame(.1,timeline);render_frame(timeline['duration']-.1,timeline)
    assert before==hashlib.sha256(render_frame(seek_t,timeline).tobytes()).hexdigest()
    with_audio={'decodeVerified':True,'streamProbe':'FFmpeg stream probe; ffprobe is not bundled','meanVolumeDb':mean,'peakVolumeDb':peak,'lastSpeechEnd':timeline['cues'][-1]['end'],'captionTiming':'sentence-level, measured PCM durations','deterministicSeekVerified':True,'encodedFramesExtractedAt':times,'tts':timeline['tts']}
    return with_audio

def contacts(timelines):
    for timeline in timelines:
        key=timeline['key'];samples=[]
        paths=sorted((ROOT/'qa').glob(f'{key}-decoded-*.jpg'))
        for path in paths:
            im=Image.open(path);im.thumbnail((640,360));samples.append(im.copy())
        sheet=Image.new('RGB',(1920,360*math.ceil(len(samples)/3)),BG)
        for j,im in enumerate(samples):sheet.paste(im,((j%3)*640,(j//3)*360))
        sheet.save(ROOT/'qa'/f'{key}-contact.jpg',quality=91)

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--key');parser.add_argument('--preview',action='store_true');parser.add_argument('--verify-only',action='store_true');parser.add_argument('--frames-only',action='store_true');args=parser.parse_args()
    timelines=[json.loads(p.read_text()) for p in sorted((ROOT/'audio').glob('*/cues.json'))]
    if args.key:timelines=[x for x in timelines if x['key']==args.key]
    reports=[]
    for timeline in timelines:
        assert timeline['cues'][-1]['end']>10,'Empty narration is not a completed video.'
        if args.frames_only:
            for j,c in enumerate(timeline['cues']):render_frame(c['start']+min(1,c['audioDuration']/2),timeline).save(ROOT/'qa'/f'{timeline["key"]}-source-{j:02d}.jpg',quality=93)
            continue
        result={'key':timeline['key']} if args.verify_only else encode(timeline,args.preview)
        if not args.preview:result.update(verify(timeline))
        reports.append(result);print(json.dumps(result,ensure_ascii=False),flush=True)
    if not args.preview and not args.frames_only:
        contacts(timelines)
        name=f'production-{args.key}.json' if args.key else 'production-report.json'
        (ROOT/'qa'/name).write_text(json.dumps({'clips':reports,'source':'https://arxiv.org/html/2610.13912v1','illustrativeStates':True,'humanListeningReview':False,'paidApisUsed':False,'costs':{'modelTokens':None,'ttsCost':None}},ensure_ascii=False,indent=2)+'\n')
        if args.key and (ROOT/'qa/production-report.json').exists():
            overall=json.loads((ROOT/'qa/production-report.json').read_text())
            replacement={r['key']:r for r in reports}
            overall['clips']=[replacement.get(r['key'],r) for r in overall['clips']]
            (ROOT/'qa/production-report.json').write_text(json.dumps(overall,ensure_ascii=False,indent=2)+'\n')

if __name__=='__main__':main()
