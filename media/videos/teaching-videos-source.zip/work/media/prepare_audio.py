"""Synthesize real Mac say narration; measure PCM audio before assigning cues.

Run using the bundled desktop Python. No account, network, or paid TTS API is used.
"""
from pathlib import Path
import json, math, os, shutil, subprocess, time, wave

ROOT = Path(__file__).resolve().parent
SITE = ROOT.parents[1]
OUT = SITE / 'dist/media/videos'
FFMPEG = os.environ.get('FFMPEG_BIN', '/Users/macbook/Documents/Codex/tools/teaching-video/.venv/lib/python3.12/site-packages/imageio_ffmpeg/binaries/ffmpeg-macos-aarch64-v7.1')
SCRIPTS = json.loads((ROOT/'scripts.json').read_text())

def run(args):
    return subprocess.run(args, check=True, capture_output=True, text=True)

def measured(path):
    with wave.open(str(path),'rb') as w:
        return w.getnframes()/w.getframerate()

def stamp(t, srt=False):
    ms=round(t*1000); h,ms=divmod(ms,3600000); m,ms=divmod(ms,60000); s,ms=divmod(ms,1000)
    return f'{h:02d}:{m:02d}:{s:02d}{"," if srt else "."}{ms:03d}'

def main():
    OUT.mkdir(parents=True,exist_ok=True)
    voices=run(['say','-v','?']).stdout
    assert 'Samantha' in voices and 'Tingting' in voices
    reports=[]
    for clip in SCRIPTS['clips']:
        for lang,voice,rate in [('en','Samantha',184),('zh','Tingting',254)]:
            key=f'{clip["id"]}-{lang}'; folder=ROOT/'audio'/key;folder.mkdir(parents=True,exist_ok=True)
            started=time.monotonic()
            for attempt in range(3):
                durations=[]
                for i,text in enumerate(clip[lang]):
                    txt=folder/f'{i+1:02d}.txt'; aiff=folder/f'{i+1:02d}.aiff'; wav=folder/f'{i+1:02d}.wav'
                    txt.write_text(text+'\n')
                    run(['say','-v',voice,'-r',str(rate),'-f',str(txt),'-o',str(aiff)])
                    run([FFMPEG,'-y','-loglevel','error','-i',str(aiff),'-ac','1','-ar','48000','-c:a','pcm_s16le',str(wav)])
                    seconds=measured(wav)
                    assert seconds>.3, (key,i,'The speech service returned empty audio. Run synthesis with speech-service access.')
                    durations.append(seconds)
                length=sum(durations)+.4+.27*(len(durations)-1)+.65
                if length<=30:break
                rate=math.ceil(rate*(length-.5)/28.5)
            assert length<=31,(key,length,rate)
            # Hold a complete closing frame; narration is never cut or time-compressed.
            duration=math.ceil(max(24,length)*24)/24
            cues=[]; cursor=.4
            for i,(text,seconds,action) in enumerate(zip(clip[lang],durations,clip['actions'])):
                cues.append({'scene':f'{clip["id"]}-{i+1:02d}','index':i,'start':round(cursor,5),'end':round(cursor+seconds,5),'audioDuration':seconds,'audioFile':str((folder/f'{i+1:02d}.wav').relative_to(ROOT)),'narration':text,'subtitle':text,'action':action})
                cursor+=seconds+.27
            narration=folder/'narration.wav'
            with wave.open(str(narration),'wb') as w:
                w.setnchannels(1);w.setsampwidth(2);w.setframerate(48000)
                frame_cursor=0
                for cue in cues:
                    start_frame=round(cue['start']*48000)
                    w.writeframes(b'\0\0'*(start_frame-frame_cursor))
                    with wave.open(str(ROOT/cue['audioFile']),'rb') as source:
                        data=source.readframes(source.getnframes());w.writeframes(data);frame_cursor=start_frame+len(data)//2
                w.writeframes(b'\0\0'*(round(duration*48000)-frame_cursor))
            timeline={'key':key,'clip':clip['id'],'lang':lang,'title':clip['title'],'duration':duration,'fps':24,'width':1920,'height':1080,'narrationFile':str(narration.relative_to(ROOT)),'tts':{'engine':'macOS say','voice':voice,'rate':rate,'synthetic':True,'timeCompression':False},'cues':cues,'source':SCRIPTS['source'],'sourceSections':clip['sourceSections'],'illustrative':True}
            (folder/'cues.json').write_text(json.dumps(timeline,ensure_ascii=False,indent=2)+'\n')
            (OUT/f'{key}.vtt').write_text('WEBVTT\n\n'+'\n\n'.join(f'{stamp(c["start"])} --> {stamp(c["end"])}\n{c["subtitle"]}' for c in cues)+'\n')
            (OUT/f'{key}.srt').write_text('\n\n'.join(f'{i+1}\n{stamp(c["start"],True)} --> {stamp(c["end"],True)}\n{c["subtitle"]}' for i,c in enumerate(cues))+'\n')
            (folder/'narration.txt').write_text('\n\n'.join(clip[lang])+'\n')
            reports.append({'key':key,'seconds':duration,'lastSpeechEnd':cues[-1]['end'],'tts':timeline['tts'],'synthesisWallSeconds':round(time.monotonic()-started,2)})
            print(json.dumps(reports[-1],ensure_ascii=False),flush=True)
    (ROOT/'timing-report.json').write_text(json.dumps(reports,ensure_ascii=False,indent=2)+'\n')

if __name__=='__main__':main()
