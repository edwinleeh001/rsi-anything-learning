"""Final ffprobe acceptance, local manifest, and a source pack without tools/frames."""
from pathlib import Path
import argparse, hashlib, json, shutil, subprocess, zipfile

ROOT=Path(__file__).resolve().parent
SITE=ROOT.parents[1]
OUT=SITE/'dist/media/videos'

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--ffprobe',default=str(ROOT/'tools/ffprobe'));args=parser.parse_args()
    production=json.loads((ROOT/'qa/production-report.json').read_text())
    scripts=json.loads((ROOT/'scripts.json').read_text());by_id={c['id']:c for c in scripts['clips']}
    titles={'loop':{'zh':'完整闭环：什么进入下一轮？','en':'The retained improvement loop'},'repair':{'zh':'四个候选，一次执行','en':'Four candidates, one execution'},'retention':{'zh':'更新不等于接受','en':'An update is not acceptance'}}
    probes=[];manifest=[]
    for report in production['clips']:
        key=report['key'];kind,lang=key.rsplit('-',1);timeline=json.loads((ROOT/'audio'/key/'cues.json').read_text());video=OUT/f'{key}.mp4'
        result=subprocess.run([args.ffprobe,'-v','error','-count_frames','-show_streams','-show_format','-of','json',str(video)],check=True,capture_output=True,text=True)
        probe=json.loads(result.stdout);streams=probe['streams'];vs=next(s for s in streams if s['codec_type']=='video');au=next(s for s in streams if s['codec_type']=='audio')
        assert vs['codec_name']=='h264' and vs['width']==1920 and vs['height']==1080 and vs['r_frame_rate']=='24/1'
        assert au['codec_name']=='aac' and au['sample_rate']=='48000'
        assert abs(float(probe['format']['duration'])-timeline['duration'])<.05
        assert int(vs['nb_read_frames'])==round(timeline['duration']*24)
        assert abs(float(au['duration'])-timeline['duration'])<.05
        assert timeline['cues'][-1]['end']<float(au['duration'])-.3
        (ROOT/'qa'/f'{key}-ffprobe.json').write_text(json.dumps(probe,indent=2)+'\n')
        report['ffprobeVerified']=True;report['streamProbe']='ffprobe 7.1 + complete FFmpeg decode';report['sha256']=hashlib.sha256(video.read_bytes()).hexdigest()
        probes.append({'key':key,'seconds':float(probe['format']['duration']),'width':vs['width'],'height':vs['height'],'fps':vs['r_frame_rate'],'frames':int(vs['nb_read_frames']),'videoCodec':vs['codec_name'],'audioCodec':au['codec_name'],'audioSampleRate':au['sample_rate'],'audioChannels':au['channels'],'audioDuration':float(au['duration']),'lastSpeechEnd':timeline['cues'][-1]['end']})
        manifest.append({'id':key,'clip':kind,'language':lang,'title':titles[kind][lang],'duration':timeline['duration'],'width':1920,'height':1080,'fps':24,'src':f'media/videos/{key}.mp4','poster':f'media/videos/{key}.jpg','vtt':f'media/videos/{key}.vtt','srt':f'media/videos/{key}.srt','subtitlesBurnedIn':True,'tts':timeline['tts'],'script':by_id[kind][lang],'cues':timeline['cues'],'source':scripts['source'],'sourceSections':by_id[kind]['sourceSections'],'illustrative':True})
    production['ffprobe']=probes
    production['validationLimitations']=['Audio presence, volume, timestamps and complete decoding were checked. No human listening review is claimed.','Sentence-level subtitle timing is based on measured audio segments; word-level timing is not claimed.','All candidates and pass/fail gate states in these animations are teaching illustrations.']
    (ROOT/'qa/production-report.json').write_text(json.dumps(production,ensure_ascii=False,indent=2)+'\n')
    (OUT/'manifest.json').write_text(json.dumps({'videos':manifest,'sourcePack':'media/videos/teaching-videos-source.zip','captionNote':'Captions are burned in. Optional VTT tracks are provided for accessibility and download; avoid displaying both simultaneously.'},ensure_ascii=False,indent=2)+'\n')
    README='''# RSI-Anything short teaching videos

Six completed 1920 × 1080, 24 fps, H.264/yuv420p MP4s with AAC 48 kHz mono narration.
Each conceptual segment has English and Mandarin variants. Canvas labels remain English;
captions follow the spoken language and are burned in. Matching sentence-level SRT/VTT
sidecars are supplied. The English variants are about 29 seconds; Mandarin about 24 seconds.

Narration was actually generated using macOS `say`: Samantha (English, rate 184) and Tingting
(Mandarin, rate 254). No paid API, music, or browser speech synthesis was used. Raw PCM
sentence lengths determine the animation and subtitle timestamps; no sentence is truncated
and no speech time compression is applied. Narration is synthetic, not a human recording.

Scientific source: RSI-Anything, arXiv:2610.13912v1, §§2.3–2.5, 3.1, 6.1.
https://arxiv.org/html/2610.13912v1

These are original teaching animations, not extracted paper figures, benchmark executions,
or experimental measurements. Four candidate patch sketches are illustrative. Only the
selected candidate receives external feedback. The fixed coder in the code experiment must
not be confused with predictor adaptation. Reliability assessment can be insufficient;
insufficient coverage does not establish reliability or activate the unreliability trigger.
Component acceptance and pair acceptance are distinct. A failed pair gate retains the
entire old pair. Update attempts are conditional and do not automatically enter the system.

## Reproduce using the included narration

Requires Python 3 with Pillow, FFmpeg with libx264/AAC, and local fonts. The defaults use
macOS Avenir Next, Menlo and Hiragino Sans GB fonts; edit font paths if using another OS.
The tools are not redistributed in this archive. From this directory:

    FFMPEG_BIN=/absolute/path/to/ffmpeg python3 render_videos.py

Render one clip or preview first:

    FFMPEG_BIN=/absolute/path/to/ffmpeg python3 render_videos.py --key loop-en --preview

To regenerate narration on macOS with speech-service access:

    FFMPEG_BIN=/absolute/path/to/ffmpeg python3 prepare_audio.py

`say` inside a restricted sandbox may return a zero-duration file. The script rejects this
condition; allow the local speech service or use the included real WAV tracks. No network
service is needed for synthesis. `audio/*/cues.json` contains measured segment durations,
actual audio file references, narration, subtitle text and visual actions. `scripts.json`
contains bilingual scripts. `render_videos.py` uses only absolute-time scene functions;
arbitrary seeking does not depend on previous frames or wall-clock state.

The original workspace exports to ../../dist/media/videos relative to this source directory.
`package_media.py --ffprobe /absolute/path/to/ffprobe` performs explicit stream/frame/audio
acceptance, writes manifest.json, and builds the source pack. `production-report.json`
records exact durations, audio levels, hashes and extracted frame times. No human listening
review is claimed. TTS costs and model token counts were not available and are left null.
'''
    (ROOT/'README.md').write_text(README)
    zip_path=ROOT/'teaching-videos-source.zip'
    with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
        for filename in ['README.md','scripts.json','prepare_audio.py','render_videos.py','package_media.py','timing-report.json']:
            z.write(ROOT/filename,Path('work/media')/filename)
        z.write(ROOT/'qa/production-report.json','work/media/qa/production-report.json')
        for path in (ROOT/'audio').rglob('*'):
            if path.is_file() and path.suffix in ('.wav','.txt','.json'):z.write(path,Path('work/media')/path.relative_to(ROOT))
        for path in OUT.glob('*'):
            if path.suffix in ('.srt','.vtt'):z.write(path,Path('dist/media/videos')/path.name)
    shutil.copy2(zip_path,OUT/zip_path.name)
    print(json.dumps({'videos':probes,'sourceZipBytes':zip_path.stat().st_size},ensure_ascii=False,indent=2))

if __name__=='__main__':main()
