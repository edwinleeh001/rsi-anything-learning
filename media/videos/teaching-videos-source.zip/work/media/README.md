# RSI-Anything short teaching videos

Six completed 1920 × 1080, 24 fps, H.264/yuv420p MP4s with AAC 48 kHz mono narration.
Each conceptual segment has English and Mandarin variants. Canvas labels remain English;
captions follow the spoken language and are burned in. Matching sentence-level SRT/VTT
sidecars are supplied. The English variants are about 29 seconds; Mandarin about 24 seconds.

Narration was actually generated using macOS `say`: Samantha (English, rate 184) and Tingting
(Mandarin, rate 254). No paid API, music, or browser speech synthesis was used. Raw PCM
sentence lengths determine the animation and subtitle timestamps; no sentence is truncated
and no speech time compression is applied. Narration is synthetic, not a human recording.

Scientific source: RSI-Anything, arXiv:2610.13912v1, §§2.3–2.5, 3.1, 6.1.
https://arxiv.org/html/2610.13912v1

These are original teaching animations, not extracted paper figures, benchmark executions,
or experimental measurements. Four candidate patch sketches are illustrative. Only the
selected candidate receives external feedback. The fixed coder in the code experiment must
not be confused with predictor adaptation. Reliability assessment can be insufficient;
insufficient coverage does not establish reliability or activate the unreliability trigger.
Component acceptance and pair acceptance are distinct. A failed pair gate retains the
entire old pair. Update attempts are conditional and do not automatically enter the system.

## Reproduce using the included narration

Requires Python 3 with Pillow, FFmpeg with libx264/AAC, and local fonts. The defaults use
macOS Avenir Next, Menlo and Hiragino Sans GB fonts; edit font paths if using another OS.
The tools are not redistributed in this archive. From this directory:

    FFMPEG_BIN=/absolute/path/to/ffmpeg python3 render_videos.py

Render one clip or preview first:

    FFMPEG_BIN=/absolute/path/to/ffmpeg python3 render_videos.py --key loop-en --preview

To regenerate narration on macOS with speech-service access:

    FFMPEG_BIN=/absolute/path/to/ffmpeg python3 prepare_audio.py

`say` inside a restricted sandbox may return a zero-duration file. The script rejects this
condition; allow the local speech service or use the included real WAV tracks. No network
service is needed for synthesis. `audio/*/cues.json` contains measured segment durations,
actual audio file references, narration, subtitle text and visual actions. `scripts.json`
contains bilingual scripts. `render_videos.py` uses only absolute-time scene functions;
arbitrary seeking does not depend on previous frames or wall-clock state.

The original workspace exports to ../../dist/media/videos relative to this source directory.
`package_media.py --ffprobe /absolute/path/to/ffprobe` performs explicit stream/frame/audio
acceptance, writes manifest.json, and builds the source pack. `production-report.json`
records exact durations, audio levels, hashes and extracted frame times. No human listening
review is claimed. TTS costs and model token counts were not available and are left null.
